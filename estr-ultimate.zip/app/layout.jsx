
import "./globals.css";

export const metadata = { title: "ESTR" };

export default function RootLayout({children}){
  return (
    <html>
      <body>{children}</body>
    </html>
  );
}
