
import axios from "axios";

export async function POST(req){
  const { address } = await req.json();

  const cg = await axios.get(
    `https://api.coingecko.com/api/v3/coins/ethereum/contract/${address}`
  );

  let honeypot = {};
  try{
    const hp = await axios.get(`https://api.honeypot.is/v2/IsHoneypot?address=${address}`);
    honeypot = hp.data;
  }catch{
    honeypot = { IsHoneypot:false };
  }

  const d = cg.data.market_data;

  const mc = d.market_cap.usd || 0;
  const vol = d.total_volume.usd || 0;

  const rug = mc < 10000 || vol < 5000 ? 70 : 10;

  return Response.json({
    name: cg.data.name,
    price: d.current_price.usd,
    marketCap: mc,
    volume: vol,
    honeypot: honeypot.IsHoneypot,
    buyTax: honeypot.BuyTax,
    sellTax: honeypot.SellTax,
    rugRiskScore: rug
  });
}
