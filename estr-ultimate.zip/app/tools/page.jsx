
"use client";
import { useState } from "react";
import axios from "axios";

export default function Tools(){
  const [addr,setAddr]=useState("");
  const [data,setData]=useState(null);

  const scan = async ()=>{
    const res = await axios.post("/api/scan",{address:addr});
    setData(res.data);
  };

  return (
    <div className="max-w-6xl mx-auto p-8 space-y-6">

      <div className="flex gap-3">
        <input
          placeholder="Enter contract address"
          className="flex-1 p-3 rounded"
          onChange={(e)=>setAddr(e.target.value)}
        />
        <button onClick={scan} className="bg-green-500 px-6 rounded">
          Scan
        </button>
      </div>

      {data && (
        <div className="grid md:grid-cols-2 gap-6">

          <div className="bg-gray-900 p-6 rounded-xl">
            <h3 className="mb-3 font-bold">Token Data</h3>
            <pre className="text-xs">{JSON.stringify(data,null,2)}</pre>
          </div>

          <iframe
            className="w-full h-[500px] rounded-xl"
            src={`https://dexscreener.com/ethereum/${addr}?embed=1&theme=dark`}
          />

        </div>
      )}
    </div>
  );
}
