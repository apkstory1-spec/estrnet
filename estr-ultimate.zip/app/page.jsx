
import Header from "@/components/Header";
import Link from "next/link";

export default function Home(){
  return (
    <main>
      <Header/>

      <section className="text-center py-32 bg-gradient-to-br from-black to-gray-900">
        <h2 className="text-5xl font-bold mb-6">Eat • Sleep • Trade • Repeat</h2>
        <p className="text-gray-400 mb-10">All-in-one crypto intelligence platform</p>
        <Link href="/tools" className="bg-green-500 px-8 py-3 rounded-2xl text-lg font-semibold">
          Launch Tools
        </Link>
      </section>

      <section className="max-w-6xl mx-auto grid md:grid-cols-3 gap-6 p-12">
        {[
          "Rug Checker",
          "Honeypot Detection",
          "Dexscreener Charts",
          "AI Risk Score",
          "Portfolio Scanner",
          "Real-time Data"
        ].map((t,i)=>(
          <div key={i} className="bg-gray-900 p-8 rounded-2xl shadow-lg hover:scale-105 transition">
            {t}
          </div>
        ))}
      </section>
    </main>
  );
}
